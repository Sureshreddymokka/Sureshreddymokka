﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using MLM.BRFactory;
using MLM.Entities;
using MLM.Common;
using System.Net;
using System.IO;

/// <summary>
/// Summary description for boards
/// </summary>
public class boards
{
    string L = "0", R = "";
    ArrayList bk;
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["str"]);
    SqlCommand cmd;
    SqlDataReader dr;
    int count = 0;
    int l1 = 0, ll2 = 0, l3 = 0;

    String u1 = "", u2 = "", u3 = "", u4 = "", u5 = "", u6 = "", u7 = "", u8 = "";
    string jointype, reduserid, redside;
	public boards()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public void moveboardB(String usr)
    { 
   string defaultLoginPassword = System.Configuration.ConfigurationManager.AppSettings["DefaultLoginPassword"].ToString();
   string defaultTransactionPassword = System.Configuration.ConfigurationManager.AppSettings["DefaultTransactionPassword"].ToString();
    String mob = "";
    String memname = "";

    string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
    try
    {
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        int k = 0;
        SqlCommand cmd = new SqlCommand("select * from members where applicationid=" + usr, con);
        SqlDataReader dr = cmd.ExecuteReader();
        int memberid = 0;
        while (dr.Read())
        {
            
            k = 9;
            memname = dr["name"].ToString();
            memberid = Int16.Parse(dr["memberid"].ToString());
            mob = dr["MobileNo"].ToString();
        }
        dr.Dispose();
        cmd.Dispose();
        if (k == 0)
        {
            //Label1.Text = "<font color=red>Application ID not found!</Font>";
        }
        else
        {

            SqlCommand cmdx = new SqlCommand("select * from tbl_boardB  where applicationid=" + usr, con);
            SqlDataReader drx = cmdx.ExecuteReader();
            k = 0;
            while (drx.Read())
            {

                k = 9;

            }
            drx.Dispose();
            cmdx.Dispose();

            if (k == 9)
            {
                //Label1.Text = "<font color=red>Application ID already moved to Circle!</Font>";
            }
            else
            {

                SqlCommand cmd2 = new SqlCommand("select * from tbl_t16", con);
                SqlDataReader dr2 = cmd2.ExecuteReader();
                k = 0;
                int appid = 0;
                string pos = "";
                while (dr2.Read())
                {

                    k = 9;

                    pos = dr2["side"].ToString();

                }
                dr2.Dispose();
                cmd2.Dispose();
                // Response.Write(pos);
                if (k == 0)
                {
                    SqlCommand cmd1 = new SqlCommand("insert into tbl_boardB(memberid,applicationid,ul,ur,dt_created,status) values(" + memberid + "," + usr + ",0,0,getdate(),0)", con);
                    cmd1.ExecuteNonQuery();
                    SqlCommand cmd3 = new SqlCommand("insert into tbl_t16(side) values('ul')", con);
                    cmd3.ExecuteNonQuery();
                   // Label1.Text = "<font color=green>" + usr + " moved successfully</font>";
                }
                else
                {
                    if (pos.Trim().Equals("ul"))
                    {
                        SqlCommand cmd1 = new SqlCommand("insert into tbl_boardB(memberid,applicationid,ul,ur,dt_created,status) values(" + memberid + "," + usr + ",0,0,getdate(),0)", con);
                        cmd1.ExecuteNonQuery();
                        SqlCommand cmd1a = new SqlCommand("delete from tbl_t16", con);
                        cmd1a.ExecuteNonQuery();

                        SqlCommand cmd211 = new SqlCommand("select top 1 * from tbl_boardB where ul= 0 order by id", con);
                        SqlDataReader dr211 = cmd211.ExecuteReader();
                        k = 0;
                        int appid1 = 0;
                        pos = "";
                        while (dr211.Read())
                        {

                            k = 9;
                            appid1 = Int16.Parse(dr211["applicationid"].ToString());
                            //pos = rl;// dr21["position"].ToString();

                        }
                        dr211.Dispose();
                        cmd211.Dispose();

                        SqlCommand cmd3 = new SqlCommand("insert into tbl_t16(side) values('rl')", con);
                        cmd3.ExecuteNonQuery();
                        SqlCommand cmd3a = new SqlCommand("update  tbl_boardB set ul=" + usr + " where applicationid=" + appid1, con);
                        cmd3a.ExecuteNonQuery();
                     //   Label1.Text = "<font color=green>" + usr + " moved successfully</font>";
                    }
                    if (pos.Trim().Equals("rl"))
                    {
                        SqlCommand cmd1 = new SqlCommand("insert into tbl_boardB(memberid,applicationid,ul,ur,dt_created,status) values(" + memberid + "," + usr + ",0,0,getdate(),0)", con);
                        cmd1.ExecuteNonQuery();
                        SqlCommand cmd1a = new SqlCommand("delete from tbl_t16", con);
                        cmd1a.ExecuteNonQuery();
                        SqlCommand cmd211 = new SqlCommand("select top 1 * from tbl_boardB where ur= 0 order by id", con);
                        SqlDataReader dr211 = cmd211.ExecuteReader();
                        k = 0;
                        int appid1 = 0;
                        pos = "";
                        while (dr211.Read())
                        {

                            k = 9;
                            appid1 = Int16.Parse(dr211["applicationid"].ToString());
                            //pos = rl;// dr21["position"].ToString();

                        }
                        dr211.Dispose();
                        cmd211.Dispose();
                        SqlCommand cmd3a = new SqlCommand("update  tbl_boardB set ur=" + usr + " where applicationid=" + appid1, con);
                        cmd3a.ExecuteNonQuery();


                        SqlCommand cmd3 = new SqlCommand("insert into tbl_t16(side) values('ul')", con);
                        cmd3.ExecuteNonQuery();

                      //  Label1.Text = "<font color=green>" + usr + " moved successfully</font>";
                        if (mob.Length > 10)
                        {
                            mob = mob.Substring(2);
                        }

                        //SqlCommand cmdxx = new SqlCommand("select * from tbl_boardB  where status=0", con);
                        //SqlDataReader drxx = cmdxx.ExecuteReader();
                        //boards b = new boards();
                        //while (drxx.Read())
                        //{

                        //    int fl = b.getboardAcount(drxx["applicationid"].ToString());
                        //    if (fl >= 14)
                        //    {

                        //        SqlConnection con1 = new SqlConnection(constr);
                        //        con1.Open();
                        //        SqlCommand cmdx1 = new SqlCommand("update tbl_boardB  set status=1 where applicationid=" + drxx["applicationid"].ToString() + "", con1);
                        //        cmdx1.ExecuteNonQuery();

                        //        cmdx1.Dispose();
                        //        con1.Close();

                        //    }


                        //}
                        //drxx.Dispose();
                        //cmdxx.Dispose();


                        //String result = GetPageContent("http://www.vnssms.in/quicksms/api.php?username=maxbulksms&password=123456789&to=" + mob + "&from=BNPLOY&message=Dear " + memname + ", Your ID :" + usr + " promoted to Circle - 1. Thank you from www.Online Cosultation.co.in");
                    }
                }

            }
        }
    }
    catch (Exception ex)
    {
       
    }

    }
    private static string GetPageContent(string FullUri)
    {
        HttpWebRequest Request;
        StreamReader ResponseReader;
        Request = ((HttpWebRequest)(WebRequest.Create(FullUri)));
        ResponseReader = new StreamReader(Request.GetResponse().GetResponseStream());
        return ResponseReader.ReadToEnd();
    }
    public int getboardAcount(String appid)
    {
        String usr = appid;
        DataTable userD = new DataTable();
        TreeShow ss = new TreeShow();
        userD = ss.fillUserDetail(appid);
        //count = count + 1;
        count = 0;
        if (userD.Rows.Count != 0)
        {

        }


        ss.find(usr, out L, out R);
        string l2 = L.ToString();
        string r3 = R.ToString();
        if (l2 != "")
        {
            //  Lb2L.Visible = true;
            //  Lb2L.Text = l2;
            cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l2 + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            jointype = "0";
            if (dr.Read())
            {
                jointype = dr[0].ToString();
            }
            con.Close();
            if (jointype.Equals("0"))
            {



            }
            else
            {

                count = count + 1;
                l1 = l1 + 1;
            }
            ss.find(l2, out L, out R);
            string l4 = L.ToString();
            string r5 = R.ToString();

            if (l4 != "")
            {
                //   Lb4L.Visible = true;
                //   Lb4L.Text = l4;
                cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l4 + "'", con);
                con.Open();
                dr = cmd.ExecuteReader();
                jointype = "0";
                if (dr.Read())
                {
                    jointype = dr[0].ToString();
                }
                con.Close();
                if (jointype.Equals("0"))
                {

                    //    i4.Src = "TreeImages/G.jpg";
                    //     Lb4L.Visible = false;

                }
                else
                {
                    // i4.Src = "TreeImages/B.jpg";
                    count = count + 1; ll2 = ll2 + 1;
                }

                ss.find(l4, out L, out R);
                string l8 = L.ToString();
                string r9 = R.ToString();

                if (l8 != "")
                {
                    //Lb8L.Visible = true;
                    //  Lb8L.Text = l8;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l8 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //   i8.Src = "TreeImages/G.jpg";
                        //   Lb8L.Visible = false;

                    }
                    else
                    {
                        //i8.Src = "TreeImages/B.jpg"; 
                        count = count + 1; l3 = l3 + 1;
                        u1 = l8;
                    }

                }
                if (r9 != "")
                {
                    //  Lb9R.Visible = true;
                    // Lb9R.Text = r9;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r9 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        // i9.Src = "TreeImages/G.jpg";
                        //  Lb9R.Visible = false;

                    }
                    else
                    {
                        ///  i9.Src = "TreeImages/B.jpg"; 
                        count = count + 1; l3 = l3 + 1;
                        u2 = r9;
                    }

                }
            }
            if (r5 != "")
            {
                //  Lb5R.Visible = true;
                //  Lb5R.Text = r5;
                cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r5 + "'", con);
                con.Open();
                dr = cmd.ExecuteReader();
                jointype = "0";
                if (dr.Read())
                {
                    jointype = dr[0].ToString();
                }
                con.Close();
                if (jointype.Equals("0"))
                {

                    // i5.Src = "TreeImages/G.jpg";
                    //  Lb5R.Visible = false;

                }
                else
                {
                    //   i5.Src = "TreeImages/B.jpg"; 
                    count = count + 1; ll2 = ll2 + 1;
                }

                ss.find(r5, out L, out R);
                string l10 = L.ToString();
                string r11 = R.ToString();

                if (l10 != "")
                {
                    // Lb10L.Visible = true;
                    // Lb10L.Text = l10;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l10 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //i10.Src = "TreeImages/G.jpg";
                        //Lb10L.Visible = false;

                    }
                    else
                    {
                        //i10.Src = "TreeImages/B.jpg"; 
                        count = count + 1; l3 = l3 + 1;
                        u3 = l10;
                    }

                }
                if (r11 != "")
                {
                    //Lb11R.Visible = true;
                    //Lb11R.Text = r11;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r11 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //i11.Src = "TreeImages/G.jpg";
                        //Lb11R.Visible = false;

                    }
                    else
                    {
                        //i11.Src = "TreeImages/B.jpg"; 
                        count = count + 1; l3 = l3 + 1;
                        u4 = r11;
                    }

                }
            }
        }
        if (r3 != "")
        {
            //Lb3R.Visible = true;
            //Lb3R.Text = r3;
            cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r3 + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            jointype = "0";
            if (dr.Read())
            {
                jointype = dr[0].ToString();
            }
            con.Close();
            if (jointype.Equals("0"))
            {

                //i3.Src = "TreeImages/G.jpg";
                //Lb3R.Visible = false;

            }
            else
            {
                //i3.Src = "TreeImages/B.jpg";
                count = count + 1; l1 = l1 + 1;
            }

            ss.find(r3, out L, out R);
            string l6 = L.ToString();
            string r7 = R.ToString();
            if (l6 != "")
            {
                //Lb6L.Visible = true;
                //Lb6L.Text = l6;
                cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l6 + "'", con);
                con.Open();
                dr = cmd.ExecuteReader();
                jointype = "0";
                if (dr.Read())
                {
                    jointype = dr[0].ToString();
                }
                con.Close();
                if (jointype.Equals("0"))
                {

                    //i6.Src = "TreeImages/G.jpg";
                    //Lb6L.Visible = false;

                }
                else
                {
                    //i6.Src = "TreeImages/B.jpg"; 
                    count = count + 1; ll2 = ll2 + 1;
                }

                ss.find(l6, out L, out R);
                string l12 = L.ToString();
                string r13 = R.ToString();
                if (l12 != "")
                {
                    //Lb12L.Visible = true;
                    //Lb12L.Text = l12;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l12 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //i12.Src = "TreeImages/G.jpg";
                        //Lb12L.Visible = false;

                    }
                    else
                    {
                        //   i12.Src = "TreeImages/B.jpg"; 
                        count = count + 1; l3 = l3 + 1;
                        u5 = l12;
                    }

                }
                if (r13 != "")
                {
                    //Lb13R.Visible = true;
                    //Lb13R.Text = r13;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r13 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //i13.Src = "TreeImages/G.jpg";
                        //Lb13R.Visible = false;

                    }
                    else
                    {
                        //i13.Src = "TreeImages/B.jpg"; 
                        count = count + 1; l3 = l3 + 1;
                        u6 = r13;
                    }



                }
            }
            if (r7 != "")
            {
                //Lb7R.Visible = true;
                //Lb7R.Text = r7;
                cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r7 + "'", con);
                con.Open();
                dr = cmd.ExecuteReader();
                jointype = "0";
                if (dr.Read())
                {
                    jointype = dr[0].ToString();
                }
                con.Close();
                if (jointype.Equals("0"))
                {

                    // i7.Src = "TreeImages/G.jpg";
                    //Lb7R.Visible = false;

                }
                else
                {
                    //  i7.Src = "TreeImages/B.jpg";
                    count = count + 1; ll2 = ll2 + 1;
                }

                ss.find(r7, out L, out R);
                string l14 = L.ToString();
                string r15 = R.ToString();
                if (l14 != "")
                {
                    //  Lb14L.Visible = true;
                    //  Lb14L.Text = l14;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + l14 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //  i14.Src = "TreeImages/G.jpg";
                        // Lb14L.Visible = false;

                    }
                    else
                    {
                        // i14.Src = "TreeImages/B.jpg";
                        count = count + 1; l3 = l3 + 1;
                        u7 = l14;
                    }

                }
                if (r15 != "")
                {
                    //Lb15R.Visible = true;
                    //Lb15R.Text = r15;
                    cmd = new SqlCommand("select * from tbl_boardA  where applicationid='" + r15 + "'", con);
                    con.Open();
                    dr = cmd.ExecuteReader();
                    jointype = "0";
                    if (dr.Read())
                    {
                        jointype = dr[0].ToString();
                    }
                    con.Close();
                    if (jointype.Equals("0"))
                    {

                        //i15.Src = "TreeImages/G.jpg";
                        // Lb15R.Visible = false;

                    }
                    else
                    {
                        //i15.Src = "TreeImages/B.jpg";
                        count = count + 1; l3 = l3 + 1;
                        u8 = r15;
                    }

                }
            }
        }
        //if (Lb2L.Text.Equals("Blank"))        {            i2.Src = "TreeImages/G.jpg";            Lb2L.Visible = false;         }
        //if (Lb3R.Text.Equals("Blank"))
        //{ i3.Src = "TreeImages/G.jpg"; Lb3R.Visible = false; }
        //if (Lb4L.Text.Equals("Blank")) { i4.Src = "TreeImages/G.jpg"; Lb4L.Visible = false; }
        //if (Lb5R.Text.Equals("Blank")) { i5.Src = "TreeImages/G.jpg"; Lb5R.Visible = false; }
        //if (Lb6L.Text.Equals("Blank")) { i6.Src = "TreeImages/G.jpg"; Lb6L.Visible = false; }
        //if (Lb7R.Text.Equals("Blank")) { i7.Src = "TreeImages/G.jpg"; Lb7R.Visible = false; }
        //if (Lb8L.Text.Equals("Blank")) { i8.Src = "TreeImages/G.jpg"; Lb8L.Visible = false; }
        //if (Lb9R.Text.Equals("Blank")) { i9.Src = "TreeImages/G.jpg"; Lb9R.Visible = false; }
        //if (Lb10L.Text.Equals("Blank")) { i10.Src = "TreeImages/G.jpg"; Lb10L.Visible = false; }
        //if (Lb11R.Text.Equals("Blank")) { i11.Src = "TreeImages/G.jpg"; Lb11R.Visible = false; }
        //if (Lb12L.Text.Equals("Blank")) { i12.Src = "TreeImages/G.jpg"; Lb12L.Visible = false; }
        //if (Lb13R.Text.Equals("Blank")) { i13.Src = "TreeImages/G.jpg"; Lb13R.Visible = false; }
        //if (Lb14L.Text.Equals("Blank")) { i14.Src = "TreeImages/G.jpg"; Lb14L.Visible = false; }
        //if (Lb15R.Text.Equals("Blank")) { i15.Src = "TreeImages/G.jpg"; Lb15R.Visible = false; }
        //lblpair.Text = "" + count;
        //Label2.Text = "" + l1;
        // Label3.Text = "" + ll2;
        // Label4.Text = "" + l3;
        // Label4.Text=u1+u2+u3+u4+u5+u6+u7+"<br>"+u8;
        // Label5.Text = "23424----"+u5;
        return count;



    }
}