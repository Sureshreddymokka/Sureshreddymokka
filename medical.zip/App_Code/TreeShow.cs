﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for TreeShow
/// </summary>
public class TreeShow
{

        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;
        DataTable dt;
        SqlDataReader dr;
        string sql;

        int status;
        public TreeShow()
        {
            con = new SqlConnection(ConfigurationSettings.AppSettings["str"]);
        }

        string msg;

        public void find(string apid, out string Left, out string Right)
        {
            Left = "";
            Right = "";
            cmd = new SqlCommand("select ul,ur from tbl_boardA where applicationid='" + apid + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                if (dr[0].ToString() != "")
                {
                    Left = dr[0].ToString();
                }
                if (dr[1].ToString() != "")
                {

                    Right = dr[1].ToString();
                }
            }
            con.Close();
        }

        public DataTable fillUserDetail(string apid)
        {
            DataTable ufill = new DataTable();
            da = new SqlDataAdapter("select * from tbl_boardA where applicationid='" + apid + "'", con);
            da.Fill(ufill);
            return ufill;

        }


        public void find1(string apid, out string Left, out string Right)
        {
            Left = "";
            Right = "";
            cmd = new SqlCommand("select ul,ur from tbl_boardB where applicationid='" + apid + "'", con);
            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                if (dr[0].ToString() != "")
                {
                    Left = dr[0].ToString();
                }
                if (dr[1].ToString() != "")
                {

                    Right = dr[1].ToString();
                }
            }
            con.Close();
        }

        public DataTable fillUserDetail1(string apid)
        {
            DataTable ufill = new DataTable();
            da = new SqlDataAdapter("select * from tbl_boardB where applicationid='" + apid + "'", con);
            da.Fill(ufill);
            return ufill;

        }

}